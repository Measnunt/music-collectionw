import { useState } from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from './ui/dialog';
import { Button } from './ui/button';
import { Card } from './ui/card';
import { Badge } from './ui/badge';
import { Crown, Users, Check, X, CreditCard, Shield, Zap, Upload } from 'lucide-react';

interface UpgradeModalProps {
  isOpen: boolean;
  onClose: () => void;
  onUpgrade: () => void;
  currentUser: {
    name: string;
    email: string;
    accountType: 'demo' | 'premium';
  };
}

export function UpgradeModal({ isOpen, onClose, onUpgrade, currentUser }: UpgradeModalProps) {
  const [isProcessing, setIsProcessing] = useState(false);

  const handleUpgrade = async () => {
    setIsProcessing(true);
    
    // Simulate payment processing
    await new Promise(resolve => setTimeout(resolve, 2000));
    
    onUpgrade();
    setIsProcessing(false);
    onClose();
  };

  const features = [
    {
      feature: 'Music Upload',
      demo: 'View Only',
      premium: 'Unlimited Uploads',
      icon: Upload
    },
    {
      feature: 'Audio Quality',
      demo: 'Standard',
      premium: 'High Quality',
      icon: Zap
    },
    {
      feature: 'Storage',
      demo: 'No Storage',
      premium: 'Unlimited Cloud Storage',
      icon: Shield
    },
    {
      feature: 'Playlist Management',
      demo: 'Limited',
      premium: 'Advanced Features',
      icon: Crown
    }
  ];

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-2xl bg-slate-900 border-slate-700">
        <DialogHeader>
          <DialogTitle className="text-center text-3xl font-bold text-white flex items-center justify-center gap-3">
            <Crown className="w-8 h-8 text-yellow-400" />
            Upgrade to Premium
          </DialogTitle>
          <DialogDescription className="text-center text-slate-400 text-lg">
            Unlock the full potential of Mussoul with Premium features
          </DialogDescription>
        </DialogHeader>
        
        <div className="space-y-8">
          {/* Current vs Premium Comparison */}
          <div className="grid grid-cols-2 gap-6">
            {/* Current Plan */}
            <Card className="bg-slate-800/50 border-slate-600 p-6">
              <div className="text-center mb-4">
                <Users className="w-8 h-8 text-blue-400 mx-auto mb-2" />
                <h3 className="text-xl font-semibold text-white">Demo Account</h3>
                <p className="text-slate-400">Current Plan</p>
                <Badge variant="secondary" className="mt-2 bg-slate-700 text-slate-300">
                  Free
                </Badge>
              </div>
            </Card>

            {/* Premium Plan */}
            <Card className="bg-gradient-to-br from-purple-500/20 to-blue-500/20 border-purple-400/50 p-6 relative overflow-hidden">
              <div className="absolute top-0 right-0 bg-gradient-to-r from-purple-500 to-blue-500 text-white text-xs px-3 py-1 rounded-bl-lg">
                Recommended
              </div>
              <div className="text-center mb-4">
                <Crown className="w-8 h-8 text-yellow-400 mx-auto mb-2" />
                <h3 className="text-xl font-semibold text-white">Premium Account</h3>
                <p className="text-slate-300">Upgrade Now</p>
                <Badge className="mt-2 bg-gradient-to-r from-purple-500 to-blue-500 text-white">
                  $9.99/month
                </Badge>
              </div>
            </Card>
          </div>

          {/* Feature Comparison */}
          <div className="space-y-4">
            <h4 className="text-lg font-semibold text-white text-center">Feature Comparison</h4>
            <div className="space-y-3">
              {features.map((item, index) => {
                const Icon = item.icon;
                return (
                  <div key={index} className="bg-slate-800/30 rounded-lg p-4">
                    <div className="grid grid-cols-3 gap-4 items-center">
                      <div className="flex items-center gap-3">
                        <Icon className="w-5 h-5 text-purple-400" />
                        <span className="text-white font-medium">{item.feature}</span>
                      </div>
                      <div className="text-center">
                        <div className="flex items-center justify-center gap-2">
                          <X className="w-4 h-4 text-red-400" />
                          <span className="text-slate-400">{item.demo}</span>
                        </div>
                      </div>
                      <div className="text-center">
                        <div className="flex items-center justify-center gap-2">
                          <Check className="w-4 h-4 text-green-400" />
                          <span className="text-green-400">{item.premium}</span>
                        </div>
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>

          {/* Premium Benefits */}
          <Card className="bg-gradient-to-r from-purple-500/10 to-blue-500/10 border-purple-500/30 p-6">
            <h4 className="text-lg font-semibold text-white mb-4 text-center">
              What You'll Get with Premium
            </h4>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="flex items-center gap-3">
                <Check className="w-5 h-5 text-green-400 flex-shrink-0" />
                <span className="text-slate-300">Unlimited music uploads</span>
              </div>
              <div className="flex items-center gap-3">
                <Check className="w-5 h-5 text-green-400 flex-shrink-0" />
                <span className="text-slate-300">High-quality audio streaming</span>
              </div>
              <div className="flex items-center gap-3">
                <Check className="w-5 h-5 text-green-400 flex-shrink-0" />
                <span className="text-slate-300">Advanced playlist management</span>
              </div>
              <div className="flex items-center gap-3">
                <Check className="w-5 h-5 text-green-400 flex-shrink-0" />
                <span className="text-slate-300">Priority customer support</span>
              </div>
              <div className="flex items-center gap-3">
                <Check className="w-5 h-5 text-green-400 flex-shrink-0" />
                <span className="text-slate-300">Unlimited cloud storage</span>
              </div>
              <div className="flex items-center gap-3">
                <Check className="w-5 h-5 text-green-400 flex-shrink-0" />
                <span className="text-slate-300">No ads or limitations</span>
              </div>
            </div>
          </Card>

          {/* Account Info */}
          <Card className="bg-slate-800/50 border-slate-700 p-4">
            <h5 className="font-semibold text-white mb-2">Upgrading Account:</h5>
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 bg-purple-500/20 rounded-full flex items-center justify-center">
                <span className="text-purple-400 font-semibold">
                  {currentUser.name.charAt(0).toUpperCase()}
                </span>
              </div>
              <div>
                <p className="text-white font-medium">{currentUser.name}</p>
                <p className="text-slate-400 text-sm">{currentUser.email}</p>
              </div>
            </div>
          </Card>

          {/* Action Buttons */}
          <div className="flex gap-4">
            <Button 
              onClick={onClose} 
              variant="outline" 
              className="flex-1 border-slate-600 text-white hover:bg-slate-800 bg-[rgba(0,0,0,1)]"
              disabled={isProcessing}
            >
              Maybe Later
            </Button>
            <Button 
              onClick={handleUpgrade}
              className="flex-1 bg-gradient-to-r from-purple-500 to-blue-500 hover:from-purple-600 hover:to-blue-600 text-white"
              disabled={isProcessing}
            >
              {isProcessing ? (
                <>
                  <div className="w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin mr-2" />
                  Processing...
                </>
              ) : (
                <>
                  <CreditCard className="w-4 h-4 mr-2" />
                  Upgrade Now - $9.99/month
                </>
              )}
            </Button>
          </div>

          {/* Trust Indicators */}
          <div className="text-center text-sm text-slate-400">
            <p>🔒 Secure payment • Cancel anytime • 30-day money-back guarantee</p>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}