import { useState } from 'react';
import { Card } from './ui/card';
import { Button } from './ui/button';
import { Badge } from './ui/badge';
import { Play, Pause, MoreVertical, Trash2, Heart, Download } from 'lucide-react';
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger } from './ui/dropdown-menu';
import { ImageWithFallback } from './figma/ImageWithFallback';

interface Music {
  id: string;
  title: string;
  artist: string;
  album: string;
  duration: string;
  genre: string;
  coverUrl: string;
  audioUrl?: string;
  liked?: boolean;
}

interface MusicCardProps {
  music: Music;
  onDelete?: (id: string) => void;
  onDownload?: (music: Music) => void;
  canDelete?: boolean;
  onPlay?: (music: Music) => void;
  isCurrentTrack?: boolean;
  isPlaying?: boolean;
  onToggleLike?: (id: string) => void;
}

export function MusicCard({ 
  music, 
  onDelete, 
  onDownload,
  canDelete = false, 
  onPlay,
  isCurrentTrack = false,
  isPlaying = false,
  onToggleLike
}: MusicCardProps) {
  const [isLiked, setIsLiked] = useState(music.liked || false);

  const handlePlayPause = () => {
    if (onPlay) {
      onPlay(music);
    }
  };

  const handleLike = () => {
    const newLikedState = !isLiked;
    setIsLiked(newLikedState);
    if (onToggleLike) {
      onToggleLike(music.id);
    }
  };

  const handleDelete = () => {
    if (onDelete) {
      onDelete(music.id);
    }
  };

  const handleDownload = () => {
    if (onDownload) {
      onDownload(music);
    }
  };

  return (
    <Card className={`bg-slate-800/50 backdrop-blur-lg border-slate-700 overflow-hidden hover:bg-slate-800/70 transition-all duration-300 group ${
      isCurrentTrack ? 'ring-2 ring-purple-500/50 bg-slate-800/70' : ''
    }`}>
      <div className="relative">
        <ImageWithFallback
          src={music.coverUrl}
          alt={`${music.title} cover`}
          className="w-full h-48 object-cover"
        />
        
        {/* Play Button Overlay */}
        <div className={`absolute inset-0 bg-black/40 transition-opacity duration-300 flex items-center justify-center ${
          isCurrentTrack ? 'opacity-100' : 'opacity-0 group-hover:opacity-100'
        }`}>
          <Button
            onClick={handlePlayPause}
            size="lg"
            className={`rounded-full w-16 h-16 flex items-center justify-center shadow-lg transition-all ${
              isCurrentTrack && isPlaying
                ? 'bg-purple-500 hover:bg-purple-600 text-white animate-pulse'
                : 'bg-white/90 hover:bg-white text-black'
            }`}
            disabled={!music.audioUrl}
          >
            {isCurrentTrack && isPlaying ? (
              <Pause className="w-6 h-6" />
            ) : (
              <Play className="w-6 h-6 ml-1" />
            )}
          </Button>
        </div>
        
        {/* Genre Badge */}
        <div className="absolute top-2 left-2">
          <Badge className="bg-purple-500/80 text-white text-xs">
            {music.genre}
          </Badge>
        </div>
        
        {/* Audio indicator */}
        {music.audioUrl && (
          <div className="absolute top-2 right-12">
          </div>
        )}
        
        {/* Actions Menu */}
        <div className="absolute top-2 right-2">
          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <Button
                variant="ghost"
                size="sm"
                className="bg-black/50 hover:bg-black/70 text-white rounded-full w-8 h-8 p-0 opacity-0 group-hover:opacity-100 transition-opacity"
              >
                <MoreVertical className="w-4 h-4" />
              </Button>
            </DropdownMenuTrigger>
            <DropdownMenuContent className="bg-slate-800 border-slate-700">
              <DropdownMenuItem 
                onClick={handleLike}
                className="text-white hover:bg-slate-700"
              >
                <Heart className={`w-4 h-4 mr-2 ${isLiked ? 'fill-red-500 text-red-500' : ''}`} />
                {isLiked ? 'Unlike' : 'Like'}
              </DropdownMenuItem>
              {music.audioUrl && onDownload && (
                <DropdownMenuItem 
                  onClick={handleDownload}
                  className="text-white hover:bg-slate-700"
                >
                  <Download className="w-4 h-4 mr-2" />
                  Download
                </DropdownMenuItem>
              )}
              {canDelete && (
                <DropdownMenuItem 
                  onClick={handleDelete}
                  className="text-red-400 hover:bg-red-500/20"
                >
                  <Trash2 className="w-4 h-4 mr-2" />
                  Delete
                </DropdownMenuItem>
              )}
            </DropdownMenuContent>
          </DropdownMenu>
        </div>
      </div>
      
      <div className="p-4">
        <h3 className={`font-semibold truncate mb-1 ${
          isCurrentTrack ? 'text-purple-400' : 'text-white'
        }`}>
          {music.title}
        </h3>
        <p className="text-slate-400 text-sm truncate mb-1">
          {music.artist}
        </p>
        <p className="text-slate-500 text-xs truncate mb-2">
          {music.album}
        </p>
        
        <div className="flex items-center justify-between">
          <span className="text-xs text-slate-500">
            {music.duration}
          </span>
          <div className="flex items-center gap-1">
            {!music.audioUrl && (
              <span className="text-xs text-amber-400">No audio</span>
            )}
            <Button
              onClick={handleLike}
              variant="ghost"
              size="sm"
              className="p-1 hover:bg-slate-700/50"
            >
              <Heart className={`w-4 h-4 ${isLiked ? 'fill-red-500 text-red-500' : 'text-slate-500'}`} />
            </Button>
          </div>
        </div>
      </div>
    </Card>
  );
}