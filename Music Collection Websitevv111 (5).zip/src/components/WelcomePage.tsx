import { useState } from 'react';
import { Button } from './ui/button';
import { Card } from './ui/card';
import { Badge } from './ui/badge';
import { Music, Users, Star, Headphones } from 'lucide-react';
import { ImageWithFallback } from './figma/ImageWithFallback';

interface WelcomePageProps {
  onShowAuth: () => void;
}

export function WelcomePage({ onShowAuth }: WelcomePageProps) {
  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-purple-900 to-slate-900">
      {/* Hero Section */}
      <div className="relative overflow-hidden">
        <div className="absolute inset-0 bg-gradient-to-r from-purple-600/20 to-blue-600/20" />
        <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 pt-20 pb-32">
          <div className="text-center">
            <div className="flex items-center justify-center mb-8">
              <div className="relative">
                <div className="absolute inset-0 bg-gradient-to-r from-purple-400 to-blue-400 rounded-full blur-xl opacity-30 animate-pulse" />
                <div className="relative bg-white/10 backdrop-blur-lg rounded-full p-6 border border-white/20">
                  <Headphones className="w-12 h-12 text-white" />
                </div>
              </div>
            </div>
            
            <h1 className="text-6xl md:text-8xl font-bold text-white mb-6 tracking-tight">
              <span className="bg-gradient-to-r from-purple-400 via-pink-400 to-blue-400 bg-clip-text text-transparent">
                Mussoul
              </span>
            </h1>
            
            <p className="text-xl md:text-2xl text-gray-300 mb-12 max-w-3xl mx-auto leading-relaxed">
              Your personal music universe. Curate, organize, and enjoy your collection 
              with the most beautiful music management platform.
            </p>
            
            <div className="flex flex-col sm:flex-row gap-4 justify-center items-center">
              <Button 
                onClick={onShowAuth}
                size="lg" 
                className="bg-gradient-to-r from-purple-500 to-blue-500 hover:from-purple-600 hover:to-blue-600 text-white px-8 py-6 text-lg rounded-full border-0 shadow-2xl hover:shadow-purple-500/25 transition-all duration-300 transform hover:scale-105"
              >
                Start Your Journey
              </Button>
              <Button 
                variant="outline" 
                size="lg"
                className="border-white/30 text-white hover:bg-white/10 px-8 py-6 text-lg rounded-full backdrop-blur-lg bg-[rgba(0,0,0,1)]"
              >
                Learn More
              </Button>
            </div>
          </div>
        </div>
      </div>

      {/* Features Section */}
      <div className="relative py-24 bg-black/20 backdrop-blur-lg">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-4xl md:text-5xl font-bold text-white mb-6">
              Why Choose <span className="text-purple-400">Mussoul</span>?
            </h2>
            <p className="text-xl text-gray-300 max-w-2xl mx-auto">
              Experience music management like never before with our cutting-edge features
            </p>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <Card className="bg-white/5 backdrop-blur-lg border-white/10 p-8 hover:bg-white/10 transition-all duration-300 transform hover:scale-105">
              <div className="text-center">
                <div className="bg-gradient-to-r from-purple-500 to-blue-500 rounded-full p-4 w-16 h-16 mx-auto mb-6 flex items-center justify-center">
                  <Music className="w-8 h-8 text-white" />
                </div>
                <h3 className="text-2xl font-bold text-white mb-4">Smart Organization</h3>
                <p className="text-gray-300 leading-relaxed">
                  AI-powered music categorization and intelligent playlists that adapt to your taste
                </p>
              </div>
            </Card>
            
            <Card className="bg-white/5 backdrop-blur-lg border-white/10 p-8 hover:bg-white/10 transition-all duration-300 transform hover:scale-105">
              <div className="text-center">
                <div className="bg-gradient-to-r from-pink-500 to-purple-500 rounded-full p-4 w-16 h-16 mx-auto mb-6 flex items-center justify-center">
                  <Users className="w-8 h-8 text-white" />
                </div>
                <h3 className="text-2xl font-bold text-white mb-4">Community Driven</h3>
                <p className="text-gray-300 leading-relaxed">
                  Connect with fellow music lovers and discover new tracks through our vibrant community
                </p>
              </div>
            </Card>
            
            <Card className="bg-white/5 backdrop-blur-lg border-white/10 p-8 hover:bg-white/10 transition-all duration-300 transform hover:scale-105">
              <div className="text-center">
                <div className="bg-gradient-to-r from-blue-500 to-cyan-500 rounded-full p-4 w-16 h-16 mx-auto mb-6 flex items-center justify-center">
                  <Star className="w-8 h-8 text-white" />
                </div>
                <h3 className="text-2xl font-bold text-white mb-4">Premium Experience</h3>
                <p className="text-gray-300 leading-relaxed">
                  Unlimited storage, advanced features, and priority support for the ultimate experience
                </p>
              </div>
            </Card>
          </div>
        </div>
      </div>

      {/* Pricing Preview */}
      <div className="py-24 bg-gradient-to-r from-purple-900/50 to-blue-900/50">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-4xl font-bold text-white mb-6">Choose Your Plan</h2>
            <p className="text-xl text-gray-300">Start free or unlock premium features</p>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            <Card className="bg-white/5 backdrop-blur-lg border-white/10 p-8 text-center">
              <Badge className="mb-4 bg-gray-500/20 text-gray-300">Demo Account</Badge>
              <h3 className="text-2xl font-bold text-white mb-4">Free Forever</h3>
              <p className="text-gray-300 mb-6">Perfect for trying out Mussoul</p>
              <ul className="text-left space-y-2 text-gray-300 mb-8">
                <li>• Browse music collection</li>
                <li>• Basic playlists</li>
                <li>• Community access</li>
                <li>• Limited storage</li>
              </ul>
              <Button 
                onClick={onShowAuth}
                variant="outline" 
                className="w-full border-white/30 text-white hover:bg-white/10 bg-[rgba(0,0,0,1)]"
              >
                Try Demo
              </Button>
            </Card>
            
            <Card className="bg-gradient-to-br from-purple-500/10 to-blue-500/10 backdrop-blur-lg border-purple-400/30 p-8 text-center relative overflow-hidden">
              <div className="absolute top-4 right-4">
                <Badge className="bg-gradient-to-r from-purple-500 to-blue-500 text-white">Most Popular</Badge>
              </div>
              <Badge className="mb-4 bg-purple-500/20 text-purple-300">Premium Account</Badge>
              <h3 className="text-2xl font-bold text-white mb-4">$9.99/month</h3>
              <p className="text-gray-300 mb-6">For serious music enthusiasts</p>
              <ul className="text-left space-y-2 text-gray-300 mb-8">
                <li>• Unlimited music uploads</li>
                <li>• Advanced organization</li>
                <li>• Add & delete tracks</li>
                <li>• Premium support</li>
                <li>• Exclusive features</li>
              </ul>
              <Button 
                onClick={onShowAuth}
                className="w-full bg-gradient-to-r from-purple-500 to-blue-500 hover:from-purple-600 hover:to-blue-600 text-white border-0"
              >
                Go Premium
              </Button>
            </Card>
          </div>
        </div>
      </div>

      {/* Hero Image Section */}
      <div className="py-24 bg-black/40">
        <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="relative rounded-3xl overflow-hidden shadow-2xl">
            <ImageWithFallback 
              src="https://images.unsplash.com/photo-1737885197946-6d9d79dade89?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxtb2Rlcm4lMjBtdXNpYyUyMHN0dWRpbyUyMGhlYWRwaG9uZXN8ZW58MXx8fHwxNzU4MDgzNTYxfDA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral"
              alt="Modern music studio setup"
              className="w-full h-96 object-cover"
            />
            <div className="absolute inset-0 bg-gradient-to-t from-black/60 to-transparent" />
            <div className="absolute bottom-8 left-8 right-8">
              <h3 className="text-3xl font-bold text-white mb-2">Professional Grade</h3>
              <p className="text-xl text-gray-200">Built for audiophiles, loved by everyone</p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}