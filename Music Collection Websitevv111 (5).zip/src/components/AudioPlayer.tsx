import { useState, useEffect, useRef } from 'react';
import { Card } from './ui/card';
import { Button } from './ui/button';
import { Slider } from './ui/slider';
import { 
  Play, 
  Pause, 
  SkipBack, 
  SkipForward, 
  Volume2, 
  VolumeX,
  Repeat,
  Shuffle,
  Heart,
  X
} from 'lucide-react';

interface Music {
  id: string;
  title: string;
  artist: string;
  album: string;
  duration: string;
  genre: string;
  coverUrl: string;
  audioUrl?: string;
  liked?: boolean;
}

interface AudioPlayerProps {
  currentTrack: Music | null;
  playlist: Music[];
  isPlaying: boolean;
  onPlay: () => void;
  onPause: () => void;
  onNext: () => void;
  onPrevious: () => void;
  onClose: () => void;
  onToggleLike: (id: string) => void;
}

export function AudioPlayer({
  currentTrack,
  playlist,
  isPlaying,
  onPlay,
  onPause,
  onNext,
  onPrevious,
  onClose,
  onToggleLike
}: AudioPlayerProps) {
  const audioRef = useRef<HTMLAudioElement | null>(null);
  const playPromiseRef = useRef<Promise<void> | null>(null);
  const [currentTime, setCurrentTime] = useState(0);
  const [duration, setDuration] = useState(0);
  const [volume, setVolume] = useState(75);
  const [isMuted, setIsMuted] = useState(false);
  const [isRepeat, setIsRepeat] = useState(false);
  const [isShuffle, setIsShuffle] = useState(false);
  const [isLoading, setIsLoading] = useState(false);
  const [audioError, setAudioError] = useState(false);

  // Initialize audio element
  useEffect(() => {
    if (currentTrack?.audioUrl) {
      setIsLoading(true);
      setAudioError(false);
      
      // Clean up previous audio
      if (audioRef.current) {
        audioRef.current.pause();
        audioRef.current.currentTime = 0;
        // Cancel any pending play promise
        if (playPromiseRef.current) {
          playPromiseRef.current.catch(() => {
            // Ignore AbortError when cleaning up
          });
          playPromiseRef.current = null;
        }
      }
      
      audioRef.current = new Audio(currentTrack.audioUrl);
      audioRef.current.volume = (isMuted ? 0 : volume) / 100;
      
      const audio = audioRef.current;
      
      const handleLoadedMetadata = () => {
        setDuration(audio.duration || 0);
        setIsLoading(false);
      };
      
      const handleTimeUpdate = () => {
        setCurrentTime(audio.currentTime || 0);
      };
      
      const handleEnded = () => {
        if (isRepeat) {
          audio.currentTime = 0;
          handlePlayAudio();
        } else {
          onNext();
        }
      };
      
      const handleError = () => {
        setIsLoading(false);
        setAudioError(true);
        console.error('Audio failed to load:', currentTrack.audioUrl);
      };
      
      const handleLoadStart = () => {
        setIsLoading(true);
      };
      
      const handleCanPlay = () => {
        setIsLoading(false);
      };
      
      audio.addEventListener('loadedmetadata', handleLoadedMetadata);
      audio.addEventListener('timeupdate', handleTimeUpdate);
      audio.addEventListener('ended', handleEnded);
      audio.addEventListener('error', handleError);
      audio.addEventListener('loadstart', handleLoadStart);
      audio.addEventListener('canplay', handleCanPlay);
      
      return () => {
        audio.removeEventListener('loadedmetadata', handleLoadedMetadata);
        audio.removeEventListener('timeupdate', handleTimeUpdate);
        audio.removeEventListener('ended', handleEnded);
        audio.removeEventListener('error', handleError);
        audio.removeEventListener('loadstart', handleLoadStart);
        audio.removeEventListener('canplay', handleCanPlay);
        
        // Cancel any pending play promise
        if (playPromiseRef.current) {
          playPromiseRef.current.catch(() => {
            // Ignore AbortError when cleaning up
          });
          playPromiseRef.current = null;
        }
        
        audio.pause();
        audio.src = '';
      };
    } else {
      // Clean up when no track
      if (audioRef.current) {
        if (playPromiseRef.current) {
          playPromiseRef.current.catch(() => {
            // Ignore AbortError when cleaning up
          });
          playPromiseRef.current = null;
        }
        audioRef.current.pause();
        audioRef.current = null;
      }
      setCurrentTime(0);
      setDuration(0);
      setIsLoading(false);
      setAudioError(false);
    }
  }, [currentTrack?.audioUrl, isRepeat, onNext]);

  // Safe play function that handles promises properly
  const handlePlayAudio = async () => {
    if (!audioRef.current || audioError) return;
    
    try {
      // Cancel any existing play promise
      if (playPromiseRef.current) {
        audioRef.current.pause();
        await playPromiseRef.current.catch(() => {
          // Ignore AbortError from previous play attempt
        });
      }
      
      // Start new play promise
      playPromiseRef.current = audioRef.current.play();
      await playPromiseRef.current;
      playPromiseRef.current = null;
    } catch (error) {
      playPromiseRef.current = null;
      if (error.name !== 'AbortError') {
        console.error('Failed to play audio:', error);
        setAudioError(true);
      }
    }
  };

  // Safe pause function
  const handlePauseAudio = async () => {
    if (!audioRef.current) return;
    
    try {
      // Cancel any pending play promise
      if (playPromiseRef.current) {
        await playPromiseRef.current.catch(() => {
          // Ignore AbortError
        });
        playPromiseRef.current = null;
      }
      
      audioRef.current.pause();
    } catch (error) {
      console.error('Failed to pause audio:', error);
    }
  };

  // Handle play/pause changes
  useEffect(() => {
    if (!audioRef.current || isLoading || audioError) return;

    if (isPlaying) {
      handlePlayAudio();
    } else {
      handlePauseAudio();
    }
  }, [isPlaying, isLoading, audioError]);

  // Handle volume changes
  useEffect(() => {
    if (audioRef.current) {
      audioRef.current.volume = isMuted ? 0 : volume / 100;
    }
  }, [volume, isMuted]);

  const handleSeek = (value: number[]) => {
    if (audioRef.current && !isLoading) {
      audioRef.current.currentTime = value[0];
      setCurrentTime(value[0]);
    }
  };

  const handleVolumeChange = (value: number[]) => {
    setVolume(value[0]);
    setIsMuted(false);
  };

  const toggleMute = () => {
    setIsMuted(!isMuted);
  };

  const handlePlayPause = () => {
    if (audioError) {
      // Try to reload the track
      setAudioError(false);
      if (currentTrack?.audioUrl) {
        const audio = new Audio(currentTrack.audioUrl);
        audioRef.current = audio;
        handlePlayAudio();
      }
      return;
    }
    
    if (isPlaying) {
      onPause();
    } else {
      onPlay();
    }
  };

  const formatTime = (time: number): string => {
    if (!isFinite(time)) return '0:00';
    const minutes = Math.floor(time / 60);
    const seconds = Math.floor(time % 60);
    return `${minutes}:${seconds.toString().padStart(2, '0')}`;
  };

  if (!currentTrack) return null;

  return (
    <Card className="fixed bottom-0 left-0 right-0 bg-slate-900/95 backdrop-blur-lg border-slate-700 border-b-0 p-4 z-50">
      <div className="flex items-center gap-4">
        {/* Track Info */}
        <div className="flex items-center gap-3 min-w-0 flex-1">
          <img
            src={currentTrack.coverUrl}
            alt={currentTrack.title}
            className="w-12 h-12 rounded-lg object-cover"
          />
          <div className="min-w-0 flex-1">
            <h4 className="font-semibold text-white truncate text-sm">
              {currentTrack.title}
            </h4>
            <p className="text-slate-400 text-xs truncate">
              {currentTrack.artist}
            </p>
            {audioError && (
              <p className="text-red-400 text-xs">Failed to load audio</p>
            )}
          </div>
          <Button
            onClick={() => onToggleLike(currentTrack.id)}
            variant="ghost"
            size="sm"
            className="p-1 hover:bg-slate-700/50"
          >
            <Heart 
              className={`w-4 h-4 ${
                currentTrack.liked 
                  ? 'fill-red-500 text-red-500' 
                  : 'text-slate-400'
              }`} 
            />
          </Button>
        </div>

        {/* Main Controls */}
        <div className="flex flex-col items-center gap-2 flex-1 max-w-lg">
          <div className="flex items-center gap-2">
            <Button
              onClick={() => setIsShuffle(!isShuffle)}
              variant="ghost"
              size="sm"
              className={`p-2 ${isShuffle ? 'text-purple-400' : 'text-slate-400'}`}
            >
              <Shuffle className="w-4 h-4" />
            </Button>
            
            <Button
              onClick={onPrevious}
              variant="ghost"
              size="sm"
              className="p-2 text-slate-400 hover:text-white"
              disabled={isLoading}
            >
              <SkipBack className="w-5 h-5" />
            </Button>
            
            <Button
              onClick={handlePlayPause}
              className="bg-white text-black hover:bg-white/90 w-10 h-10 rounded-full p-0"
              disabled={isLoading && !audioError}
            >
              {isLoading ? (
                <div className="w-5 h-5 border-2 border-black/30 border-t-black rounded-full animate-spin" />
              ) : audioError ? (
                <Play className="w-5 h-5 ml-0.5" />
              ) : isPlaying ? (
                <Pause className="w-5 h-5" />
              ) : (
                <Play className="w-5 h-5 ml-0.5" />
              )}
            </Button>
            
            <Button
              onClick={onNext}
              variant="ghost"
              size="sm"
              className="p-2 text-slate-400 hover:text-white"
              disabled={isLoading}
            >
              <SkipForward className="w-5 h-5" />
            </Button>
            
            <Button
              onClick={() => setIsRepeat(!isRepeat)}
              variant="ghost"
              size="sm"
              className={`p-2 ${isRepeat ? 'text-purple-400' : 'text-slate-400'}`}
            >
              <Repeat className="w-4 h-4" />
            </Button>
          </div>

          {/* Progress Bar */}
          <div className="flex items-center gap-2 w-full">
            <span className="text-xs text-slate-400 w-10 text-right">
              {formatTime(currentTime)}
            </span>
            <Slider
              value={[currentTime]}
              max={duration || 100}
              step={1}
              onValueChange={handleSeek}
              className="flex-1"
              disabled={isLoading || audioError || !duration}
            />
            <span className="text-xs text-slate-400 w-10">
              {formatTime(duration)}
            </span>
          </div>
        </div>

        {/* Volume & Close */}
        <div className="flex items-center gap-2 flex-1 justify-end">
          <div className="flex items-center gap-2">
            <Button
              onClick={toggleMute}
              variant="ghost"
              size="sm"
              className="p-2 text-slate-400 hover:text-white"
            >
              {isMuted || volume === 0 ? (
                <VolumeX className="w-4 h-4" />
              ) : (
                <Volume2 className="w-4 h-4" />
              )}
            </Button>
            <Slider
              value={[isMuted ? 0 : volume]}
              max={100}
              step={1}
              onValueChange={handleVolumeChange}
              className="w-20"
            />
          </div>
          
          <Button
            onClick={onClose}
            variant="ghost"
            size="sm"
            className="p-2 text-slate-400 hover:text-white"
          >
            <X className="w-4 h-4" />
          </Button>
        </div>
      </div>
    </Card>
  );
}