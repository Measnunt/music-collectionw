import { useState } from 'react';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { Label } from './ui/label';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription, DialogTrigger } from './ui/dialog';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from './ui/select';
import { Plus, Upload, Music as MusicIcon, Image as ImageIcon } from 'lucide-react';
import { MusicCard } from './MusicCard';

interface Music {
  id: string;
  title: string;
  artist: string;
  album: string;
  duration: string;
  genre: string;
  coverUrl: string;
  audioUrl?: string; // New field for audio file
  liked?: boolean;
}

interface MusicManagerProps {
  music: Music[];
  onAddMusic: (music: Omit<Music, 'id'>) => void;
  onDeleteMusic: (id: string) => void;
  onDownload?: (music: Music) => void;
  canManage: boolean;
  onPlayTrack?: (music: Music) => void;
  currentTrack?: Music | null;
  isPlaying?: boolean;
  onToggleLike?: (id: string) => void;
}

export function MusicManager({ 
  music, 
  onAddMusic, 
  onDeleteMusic, 
  onDownload,
  canManage,
  onPlayTrack,
  currentTrack,
  isPlaying = false,
  onToggleLike
}: MusicManagerProps) {
  const [isAddModalOpen, setIsAddModalOpen] = useState(false);
  const [newMusic, setNewMusic] = useState({
    title: '',
    artist: '',
    album: '',
    duration: '',
    genre: '',
    coverUrl: '',
    audioUrl: ''
  });
  const [isUploading, setIsUploading] = useState(false);

  const genres = [
    'Rock', 'Pop', 'Hip Hop', 'Electronic', 'Jazz', 'Classical', 
    'Country', 'R&B', 'Alternative', 'Indie', 'Metal', 'Folk'
  ];

  // File upload handler for audio
  const handleAudioUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file && file.type.startsWith('audio/')) {
      const audioUrl = URL.createObjectURL(file);
      setNewMusic({ ...newMusic, audioUrl });
      
      // Auto-populate title from filename if empty
      if (!newMusic.title) {
        const filename = file.name.replace(/\.[^/.]+$/, ""); // Remove extension
        setNewMusic(prev => ({ ...prev, title: filename, audioUrl }));
      }
      
      // Get duration from audio file
      const audio = new Audio(audioUrl);
      audio.addEventListener('loadedmetadata', () => {
        const minutes = Math.floor(audio.duration / 60);
        const seconds = Math.floor(audio.duration % 60);
        const durationString = `${minutes}:${seconds.toString().padStart(2, '0')}`;
        setNewMusic(prev => ({ ...prev, duration: durationString }));
      });
    }
  };

  // File upload handler for cover image
  const handleCoverUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file && file.type.startsWith('image/')) {
      const coverUrl = URL.createObjectURL(file);
      setNewMusic({ ...newMusic, coverUrl });
    }
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!newMusic.title || !newMusic.artist) return;
    
    setIsUploading(true);
    
    // Simulate upload delay
    setTimeout(() => {
      // Generate a random cover if none provided
      const coverUrl = newMusic.coverUrl || `https://images.unsplash.com/photo-1493225457124-a3eb161ffa5f?w=400&h=400&fit=crop&crop=center`;
      
      onAddMusic({
        ...newMusic,
        coverUrl,
        duration: newMusic.duration || '3:30'
      });
      
      // Reset form
      setNewMusic({
        title: '',
        artist: '',
        album: '',
        duration: '',
        genre: '',
        coverUrl: '',
        audioUrl: ''
      });
      
      setIsUploading(false);
      setIsAddModalOpen(false);
    }, 1000);
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-2xl font-bold text-white">My Music Collection</h2>
          <p className="text-slate-400">
            {music.length} {music.length === 1 ? 'track' : 'tracks'} in your library
          </p>
        </div>
        
        {canManage && (
          <Dialog open={isAddModalOpen} onOpenChange={setIsAddModalOpen}>
            <DialogTrigger asChild>
              <Button className="bg-gradient-to-r from-purple-500 to-blue-500 hover:from-purple-600 hover:to-blue-600 text-white">
                <Plus className="w-4 h-4 mr-2" />
                Add Music
              </Button>
            </DialogTrigger>
            <DialogContent className="bg-slate-900 border-slate-700 max-w-md max-h-[90vh] overflow-y-auto">
              <DialogHeader>
                <DialogTitle className="text-white">Add New Music</DialogTitle>
                <DialogDescription className="text-slate-400">
                  Upload your music file and add track details
                </DialogDescription>
              </DialogHeader>
              
              <form onSubmit={handleSubmit} className="space-y-4">
                {/* Audio File Upload */}
                <div>
                  <Label htmlFor="audioFile" className="text-white">Audio File *</Label>
                  <div className="mt-2">
                    <label className="flex flex-col items-center justify-center w-full h-32 border-2 border-dashed border-slate-600 rounded-lg cursor-pointer bg-slate-800/50 hover:bg-slate-800/70 transition-colors">
                      <div className="flex flex-col items-center justify-center pt-5 pb-6">
                        <MusicIcon className="w-8 h-8 mb-2 text-slate-400" />
                        <p className="mb-2 text-sm text-slate-400">
                          <span className="font-semibold">Click to upload</span> audio file
                        </p>
                        <p className="text-xs text-slate-500">MP3, WAV, FLAC, OGG (MAX. 50MB)</p>
                      </div>
                      <input
                        id="audioFile"
                        type="file"
                        className="hidden"
                        accept="audio/*"
                        onChange={handleAudioUpload}
                      />
                    </label>
                    {newMusic.audioUrl && (
                      <p className="text-sm text-green-400 mt-2">✓ Audio file uploaded</p>
                    )}
                  </div>
                </div>

                {/* Cover Image Upload */}
                <div>
                  <Label htmlFor="coverFile" className="text-white">Cover Image</Label>
                  <div className="mt-2">
                    <label className="flex flex-col items-center justify-center w-full h-24 border-2 border-dashed border-slate-600 rounded-lg cursor-pointer bg-slate-800/50 hover:bg-slate-800/70 transition-colors">
                      <div className="flex flex-col items-center justify-center pt-3 pb-3">
                        <ImageIcon className="w-6 h-6 mb-1 text-slate-400" />
                        <p className="text-xs text-slate-400">Upload cover image</p>
                      </div>
                      <input
                        id="coverFile"
                        type="file"
                        className="hidden"
                        accept="image/*"
                        onChange={handleCoverUpload}
                      />
                    </label>
                    {newMusic.coverUrl && (
                      <div className="mt-2">
                        <img 
                          src={newMusic.coverUrl} 
                          alt="Cover preview" 
                          className="w-16 h-16 rounded-lg object-cover"
                        />
                      </div>
                    )}
                  </div>
                </div>
                
                <div>
                  <Label htmlFor="title" className="text-white">Song Title *</Label>
                  <Input
                    id="title"
                    value={newMusic.title}
                    onChange={(e) => setNewMusic({ ...newMusic, title: e.target.value })}
                    className="bg-slate-800 border-slate-600 text-white"
                    placeholder="Enter song title"
                    required
                  />
                </div>
                
                <div>
                  <Label htmlFor="artist" className="text-white">Artist *</Label>
                  <Input
                    id="artist"
                    value={newMusic.artist}
                    onChange={(e) => setNewMusic({ ...newMusic, artist: e.target.value })}
                    className="bg-slate-800 border-slate-600 text-white"
                    placeholder="Enter artist name"
                    required
                  />
                </div>
                
                <div>
                  <Label htmlFor="album" className="text-white">Album</Label>
                  <Input
                    id="album"
                    value={newMusic.album}
                    onChange={(e) => setNewMusic({ ...newMusic, album: e.target.value })}
                    className="bg-slate-800 border-slate-600 text-white"
                    placeholder="Enter album name"
                  />
                </div>
                
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <Label htmlFor="duration" className="text-white">Duration</Label>
                    <Input
                      id="duration"
                      value={newMusic.duration}
                      onChange={(e) => setNewMusic({ ...newMusic, duration: e.target.value })}
                      className="bg-slate-800 border-slate-600 text-white"
                      placeholder="3:30"
                      readOnly={!!newMusic.audioUrl}
                    />
                  </div>
                  
                  <div>
                    <Label htmlFor="genre" className="text-white">Genre</Label>
                    <Select 
                      value={newMusic.genre} 
                      onValueChange={(value) => setNewMusic({ ...newMusic, genre: value })}
                    >
                      <SelectTrigger className="bg-slate-800 border-slate-600 text-white">
                        <SelectValue placeholder="Select genre" />
                      </SelectTrigger>
                      <SelectContent className="bg-slate-800 border-slate-700">
                        {genres.map((genre) => (
                          <SelectItem key={genre} value={genre} className="text-white hover:bg-slate-700">
                            {genre}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                </div>
                
                <div className="flex gap-3 pt-4">
                  <Button 
                    type="button" 
                    variant="outline" 
                    onClick={() => setIsAddModalOpen(false)}
                    className="flex-1 border-slate-600 text-white hover:bg-slate-800 bg-[rgba(0,0,0,1)]"
                    disabled={isUploading}
                  >
                    Cancel
                  </Button>
                  <Button 
                    type="submit" 
                    className="flex-1 bg-gradient-to-r from-purple-500 to-blue-500 hover:from-purple-600 hover:to-blue-600 text-white"
                    disabled={isUploading || !newMusic.title || !newMusic.artist}
                  >
                    {isUploading ? (
                      <>
                        <div className="w-4 h-4 mr-2 border-2 border-white/30 border-t-white rounded-full animate-spin" />
                        Uploading...
                      </>
                    ) : (
                      <>
                        <Upload className="w-4 h-4 mr-2" />
                        Add Track
                      </>
                    )}
                  </Button>
                </div>
              </form>
            </DialogContent>
          </Dialog>
        )}
      </div>
      
      {/* Music Grid */}
      {music.length > 0 ? (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
          {music.map((track) => (
            <MusicCard
              key={track.id}
              music={track}
              onDelete={canManage ? onDeleteMusic : undefined}
              onDownload={onDownload}
              canDelete={canManage}
              onPlay={onPlayTrack}
              isCurrentTrack={currentTrack?.id === track.id}
              isPlaying={isPlaying && currentTrack?.id === track.id}
              onToggleLike={onToggleLike}
            />
          ))}
        </div>
      ) : (
        <div className="text-center py-16">
          <div className="bg-slate-800/50 rounded-full w-24 h-24 flex items-center justify-center mx-auto mb-4">
            <Upload className="w-12 h-12 text-slate-400" />
          </div>
          <h3 className="text-xl font-semibold text-white mb-2">No music yet</h3>
          <p className="text-slate-400 mb-6">
            {canManage 
              ? "Start building your collection by adding your first track"
              : "This library is empty. Upgrade to premium to add music!"
            }
          </p>
          {canManage && (
            <Button 
              onClick={() => setIsAddModalOpen(true)}
              className="bg-gradient-to-r from-purple-500 to-blue-500 hover:from-purple-600 hover:to-blue-600 text-white"
            >
              <Plus className="w-4 h-4 mr-2" />
              Add Your First Track
            </Button>
          )}
        </div>
      )}
    </div>
  );
}