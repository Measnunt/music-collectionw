import { useState } from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from './ui/dialog';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { Label } from './ui/label';
import { Tabs, TabsContent, TabsList, TabsTrigger } from './ui/tabs';
import { Card } from './ui/card';
import { Badge } from './ui/badge';
import { Music, Crown, Users } from 'lucide-react';

interface AuthModalProps {
  isOpen: boolean;
  onClose: () => void;
  onAuth: (user: { name: string; email: string; accountType: 'demo' | 'premium' }) => void;
}

export function AuthModal({ isOpen, onClose, onAuth }: AuthModalProps) {
  const [isLogin, setIsLogin] = useState(true);
  const [accountType, setAccountType] = useState<'demo' | 'premium'>('demo');
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    password: ''
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    // Demo authentication - in real app this would call your auth service
    const user = {
      name: formData.name || formData.email.split('@')[0],
      email: formData.email,
      accountType
    };
    
    onAuth(user);
    onClose();
    
    // Reset form
    setFormData({ name: '', email: '', password: '' });
  };

  const handleDemoLogin = () => {
    const demoUser = {
      name: 'Demo User',
      email: 'demo@mussoul.com',
      accountType: 'demo' as const
    };
    onAuth(demoUser);
    onClose();
  };

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-md bg-slate-900 border-slate-700">
        <DialogHeader>
          <DialogTitle className="text-center text-2xl font-bold text-white flex items-center justify-center gap-2">
            <Music className="w-8 h-8 text-purple-400" />
            Welcome to Mussoul
          </DialogTitle>
          <DialogDescription className="text-center text-slate-400">
            Sign in to your account or create a new one to start your music journey
          </DialogDescription>
        </DialogHeader>
        
        <Tabs value={isLogin ? 'login' : 'register'} onValueChange={(value) => setIsLogin(value === 'login')}>
          <TabsList className="grid w-full grid-cols-2 bg-slate-800">
            <TabsTrigger value="login" className="text-white data-[state=active]:bg-purple-600">
              Login
            </TabsTrigger>
            <TabsTrigger value="register" className="text-white data-[state=active]:bg-purple-600">
              Register
            </TabsTrigger>
          </TabsList>
          
          <TabsContent value="login" className="space-y-4">
            <form onSubmit={handleSubmit} className="space-y-4">
              <div>
                <Label htmlFor="email" className="text-white">Email</Label>
                <Input
                  id="email"
                  type="email"
                  value={formData.email}
                  onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                  className="bg-slate-800 border-slate-600 text-white"
                  placeholder="your@email.com"
                  required
                />
              </div>
              
              <div>
                <Label htmlFor="password" className="text-white">Password</Label>
                <Input
                  id="password"
                  type="password"
                  value={formData.password}
                  onChange={(e) => setFormData({ ...formData, password: e.target.value })}
                  className="bg-slate-800 border-slate-600 text-white"
                  placeholder="••••••••"
                  required
                />
              </div>

              <Button 
                type="submit" 
                className="w-full bg-gradient-to-r from-purple-500 to-blue-500 hover:from-purple-600 hover:to-blue-600 text-white"
              >
                Sign In
              </Button>
            </form>
            
            <div className="relative">
              <div className="absolute inset-0 flex items-center">
                <span className="w-full border-t border-slate-600" />
              </div>
              <div className="relative flex justify-center text-xs uppercase">
                <span className="bg-slate-900 px-2 text-slate-400">Or try demo</span>
              </div>
            </div>
            
            <Button 
              onClick={handleDemoLogin}
              variant="outline" 
              className="w-full border-slate-600 text-white hover:bg-slate-800 bg-[rgba(0,0,0,1)]"
            >
              <Users className="w-4 h-4 mr-2" />
              Quick Demo Access
            </Button>
          </TabsContent>
          
          <TabsContent value="register" className="space-y-4">
            <div className="space-y-4">
              <h3 className="text-lg font-semibold text-white text-center">Choose Your Plan</h3>
              
              <div className="grid grid-cols-1 gap-3">
                <Card 
                  className={`p-4 cursor-pointer border-2 transition-all ${
                    accountType === 'demo' 
                      ? 'border-purple-400 bg-purple-500/10' 
                      : 'border-slate-600 bg-slate-800'
                  }`}
                  onClick={() => setAccountType('demo')}
                >
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-3">
                      <Users className="w-5 h-5 text-blue-400" />
                      <div>
                        <h4 className="font-semibold text-white">Demo Account</h4>
                        <p className="text-sm text-slate-400">Free forever</p>
                      </div>
                    </div>
                    <Badge variant="secondary" className="bg-slate-700 text-slate-300">Free</Badge>
                  </div>
                </Card>
                
                <Card 
                  className={`p-4 cursor-pointer border-2 transition-all ${
                    accountType === 'premium' 
                      ? 'border-purple-400 bg-purple-500/10' 
                      : 'border-slate-600 bg-slate-800'
                  }`}
                  onClick={() => setAccountType('premium')}
                >
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-3">
                      <Crown className="w-5 h-5 text-yellow-400" />
                      <div>
                        <h4 className="font-semibold text-white">Premium Account</h4>
                        <p className="text-sm text-slate-400">$9.99/month</p>
                      </div>
                    </div>
                    <Badge className="bg-gradient-to-r from-purple-500 to-blue-500 text-white">
                      Popular
                    </Badge>
                  </div>
                </Card>
              </div>
            </div>
            
            <form onSubmit={handleSubmit} className="space-y-4">
              <div>
                <Label htmlFor="name" className="text-white">Full Name</Label>
                <Input
                  id="name"
                  type="text"
                  value={formData.name}
                  onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                  className="bg-slate-800 border-slate-600 text-white"
                  placeholder="John Doe"
                  required
                />
              </div>
              
              <div>
                <Label htmlFor="email-register" className="text-white">Email</Label>
                <Input
                  id="email-register"
                  type="email"
                  value={formData.email}
                  onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                  className="bg-slate-800 border-slate-600 text-white"
                  placeholder="your@email.com"
                  required
                />
              </div>
              
              <div>
                <Label htmlFor="password-register" className="text-white">Password</Label>
                <Input
                  id="password-register"
                  type="password"
                  value={formData.password}
                  onChange={(e) => setFormData({ ...formData, password: e.target.value })}
                  className="bg-slate-800 border-slate-600 text-white"
                  placeholder="••••••••"
                  required
                />
              </div>

              <Button 
                type="submit" 
                className={`w-full ${
                  accountType === 'premium'
                    ? 'bg-gradient-to-r from-purple-500 to-blue-500 hover:from-purple-600 hover:to-blue-600'
                    : 'bg-slate-700 hover:bg-slate-600'
                } text-white`}
              >
                {accountType === 'premium' ? (
                  <>
                    <Crown className="w-4 h-4 mr-2" />
                    Start Premium Trial
                  </>
                ) : (
                  <>
                    <Users className="w-4 h-4 mr-2" />
                    Create Demo Account
                  </>
                )}
              </Button>
            </form>
          </TabsContent>
        </Tabs>
      </DialogContent>
    </Dialog>
  );
}