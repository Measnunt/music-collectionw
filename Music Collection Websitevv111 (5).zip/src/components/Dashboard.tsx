import { useState } from 'react';
import { Button } from './ui/button';
import { Badge } from './ui/badge';
import { Card } from './ui/card';
import { Avatar, AvatarFallback } from './ui/avatar';
import { 
  Music, 
  Crown, 
  Users, 
  LogOut, 
  Search, 
  Home, 
  Heart,
  Settings,
  TrendingUp,
  Download,
  Share2,
  MoreHorizontal,
  Play,
  Pause,
  ArrowUpDown
} from 'lucide-react';
import { Input } from './ui/input';
import { MusicManager } from './MusicManager';
import { AudioPlayer } from './AudioPlayer';
import { UpgradeModal } from './UpgradeModal';

interface User {
  name: string;
  email: string;
  accountType: 'demo' | 'premium';
}

interface DashboardProps {
  user: User;
  onLogout: () => void;
  onUpgrade: () => void;
  musicLibrary: Music[];
  onAddMusic: (music: Omit<Music, 'id'>) => void;
  onDeleteMusic: (id: string) => void;
  onToggleLike: (id: string) => void;
}

interface Music {
  id: string;
  title: string;
  artist: string;
  album: string;
  duration: string;
  genre: string;
  coverUrl: string;
  audioUrl?: string;
  liked?: boolean;
}

export function Dashboard({ 
  user, 
  onLogout, 
  onUpgrade, 
  musicLibrary, 
  onAddMusic, 
  onDeleteMusic, 
  onToggleLike 
}: DashboardProps) {
  const [currentView, setCurrentView] = useState<'home' | 'library' | 'liked' | 'settings'>('home');
  const [searchQuery, setSearchQuery] = useState('');
  const [sortBy, setSortBy] = useState<'title' | 'artist' | 'duration' | 'genre' | 'recent'>('recent');
  const [showUpgradeModal, setShowUpgradeModal] = useState(false);

  // Audio player state
  const [currentTrack, setCurrentTrack] = useState<Music | null>(null);
  const [isPlaying, setIsPlaying] = useState(false);
  const [currentPlaylistIndex, setCurrentPlaylistIndex] = useState(0);

  const handleDeleteMusic = (id: string) => {
    onDeleteMusic(id);
    // Stop playback if deleted track is currently playing
    if (currentTrack?.id === id) {
      setCurrentTrack(null);
      setIsPlaying(false);
    }
  };

  // Audio player controls
  const handlePlayTrack = (track: Music) => {
    if (currentTrack?.id === track.id) {
      setIsPlaying(!isPlaying);
    } else {
      setCurrentTrack(track);
      setIsPlaying(true);
      const index = musicLibrary.findIndex(m => m.id === track.id);
      setCurrentPlaylistIndex(index);
    }
  };

  const handlePlay = () => setIsPlaying(true);
  const handlePause = () => setIsPlaying(false);

  const handleNext = () => {
    const nextIndex = (currentPlaylistIndex + 1) % musicLibrary.length;
    const nextTrack = musicLibrary[nextIndex];
    if (nextTrack?.audioUrl) {
      setCurrentTrack(nextTrack);
      setCurrentPlaylistIndex(nextIndex);
      setIsPlaying(true);
    }
  };

  const handlePrevious = () => {
    const prevIndex = currentPlaylistIndex === 0 ? musicLibrary.length - 1 : currentPlaylistIndex - 1;
    const prevTrack = musicLibrary[prevIndex];
    if (prevTrack?.audioUrl) {
      setCurrentTrack(prevTrack);
      setCurrentPlaylistIndex(prevIndex);
      setIsPlaying(true);
    }
  };

  const handleClosePlayer = () => {
    setCurrentTrack(null);
    setIsPlaying(false);
  };

  // Filter and sort music based on search and sort criteria
  const filteredAndSortedMusic = musicLibrary
    .filter(music => {
      if (!searchQuery) return true;
      const query = searchQuery.toLowerCase();
      return (
        music.title.toLowerCase().includes(query) ||
        music.artist.toLowerCase().includes(query) ||
        music.album.toLowerCase().includes(query) ||
        music.genre.toLowerCase().includes(query)
      );
    })
    .sort((a, b) => {
      switch (sortBy) {
        case 'title':
          return a.title.localeCompare(b.title);
        case 'artist':
          return a.artist.localeCompare(b.artist);
        case 'genre':
          return a.genre.localeCompare(b.genre);
        case 'duration':
          // Convert duration to seconds for comparison
          const aDuration = a.duration.split(':').reduce((acc, time) => (60 * acc) + +time, 0);
          const bDuration = b.duration.split(':').reduce((acc, time) => (60 * acc) + +time, 0);
          return aDuration - bDuration;
        case 'recent':
        default:
          return 0; // Keep original order for recent
      }
    });

  const likedMusic = musicLibrary.filter(music => music.liked);
  const isPremium = user.accountType === 'premium';

  // Download function
  const handleDownload = async (track: Music) => {
    if (!track.audioUrl) {
      alert('No audio file available for download');
      return;
    }

    try {
      const response = await fetch(track.audioUrl);
      const blob = await response.blob();
      const url = window.URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = `${track.artist} - ${track.title}.mp3`;
      document.body.appendChild(a);
      a.click();
      window.URL.revokeObjectURL(url);
      document.body.removeChild(a);
    } catch (error) {
      console.error('Download failed:', error);
      alert('Download failed. Please try again.');
    }
  };

  const sidebarItems = [
    { id: 'home', label: 'Home', icon: Home },
    { id: 'library', label: 'Your Library', icon: Music },
    { id: 'liked', label: 'Liked Songs', icon: Heart },
    { id: 'settings', label: 'Settings', icon: Settings }
  ];

  const renderContent = () => {
    switch (currentView) {
      case 'home':
        return (
          <div className="space-y-0">
            {/* Hero Section */}
            <div className="relative bg-gradient-to-r from-slate-900 via-purple-900/30 to-slate-900 p-16 mb-12">
              <div className="flex items-center justify-between">
                <div className="flex-1 max-w-2xl">
                  <h1 className="text-5xl font-bold text-white mb-6 leading-tight">
                    Get royalty-free music for your videos
                  </h1>
                  <p className="text-xl text-slate-300 mb-8 leading-relaxed">
                    Explore copyright-free music with music licensing that covers any kind of project, from social media to commercial use worldwide.
                  </p>
                  <div className="flex gap-4">
                    <Button 
                      onClick={() => setCurrentView('library')}
                      className="bg-[rgba(160,0,240,1)] hover:bg-yellow-400 text-black px-8 py-3 rounded-full text-lg font-semibold"
                    >
                      Start Free Now
                    </Button>
                    <Button 
                      onClick={() => setShowUpgradeModal(true)}
                      variant="outline"
                      className="border-slate-400 text-[rgba(0,0,0,1)] hover:bg-slate-800 px-8 py-3 rounded-full text-lg bg-[rgba(255,255,255,1)]"
                    >
                      Pricing
                    </Button>
                  </div>
                </div>
                <div className="hidden lg:block">
                  <img 
                    src="https://images.unsplash.com/photo-1745847768404-4303495b1116?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxwcm9mZXNzaW9uYWwlMjBtdXNpYyUyMHN0dWRpb3xlbnwxfHx8fDE3NTgxMTYxNTl8MA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral"
                    alt="Music Studio"
                    className="w-96 h-96 object-cover rounded-2xl"
                  />
                </div>
              </div>
            </div>
            {/* Music Library */}
            <div className="py-8">
              {/* Search Results Info */}
              {searchQuery && (
                <div className="mb-4">
                  <p className="text-slate-300">
                    {filteredAndSortedMusic.length} result{filteredAndSortedMusic.length !== 1 ? 's' : ''} for "{searchQuery}"
                  </p>
                </div>
              )}

              {/* Filters */}
              <div className="flex items-center justify-between mb-6">
                <div className="flex items-center gap-4">
                  <select className="bg-slate-800 border border-slate-600 rounded-lg px-4 py-2 text-white">
                    <option>Genre</option>
                    <option>Rock</option>
                    <option>Pop</option>
                    <option>Electronic</option>
                    <option>Jazz</option>
                  </select>
                  <select className="bg-slate-800 border border-slate-600 rounded-lg px-4 py-2 text-white">
                    <option>Mood</option>
                    <option>Energetic</option>
                    <option>Calm</option>
                    <option>Dark</option>
                    <option>Happy</option>
                  </select>
                  <select className="bg-slate-800 border border-slate-600 rounded-lg px-4 py-2 text-white">
                    <option>Instrument</option>
                    <option>Piano</option>
                    <option>Guitar</option>
                    <option>Synth</option>
                    <option>Drums</option>
                  </select>
                </div>
                <div className="flex items-center gap-2 text-slate-400">
                  <span>Sort by: {sortBy === 'recent' ? 'Recent' : sortBy.charAt(0).toUpperCase() + sortBy.slice(1)}</span>
                </div>
              </div>

              {/* Track List */}
              {filteredAndSortedMusic.length > 0 ? (
                <div className="space-y-3">
                  {filteredAndSortedMusic.map((track, index) => (
                  <div key={track.id} className="flex items-center gap-4 p-4 rounded-lg hover:bg-slate-800/30 transition-colors group">
                    {/* Play Button & Album Art */}
                    <div className="relative">
                      <img 
                        src={track.coverUrl} 
                        alt={track.title}
                        className="w-16 h-16 rounded-lg object-cover"
                      />
                      <button 
                        onClick={() => handlePlayTrack(track)}
                        className="absolute inset-0 bg-black/60 rounded-lg flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity"
                      >
                        {currentTrack?.id === track.id && isPlaying ? (
                          <Pause className="w-5 h-5 text-white" />
                        ) : (
                          <Play className="w-5 h-5 text-white" />
                        )}
                      </button>
                    </div>

                    {/* Track Info */}
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center gap-3 mb-1">
                        <h3 className="font-semibold text-white truncate">{track.title}</h3>
                        {track.liked && <span className="text-red-400 text-xs">NEW</span>}
                      </div>
                      <p className="text-slate-400 text-sm">{track.artist}</p>
                    </div>

                    {/* Genre */}
                    <div className="hidden sm:block">
                      <Badge className="bg-slate-700 text-slate-300 hover:bg-slate-600">
                        {track.genre}
                      </Badge>
                    </div>

                    {/* Waveform */}
                    <div className="hidden md:flex items-center gap-1 w-32">
                      {[...Array(20)].map((_, i) => (
                        <div 
                          key={i}
                          className="bg-slate-600 rounded-full"
                          style={{
                            width: '2px',
                            height: `${Math.random() * 20 + 8}px`,
                            opacity: currentTrack?.id === track.id && isPlaying && i < 10 ? 1 : 0.5
                          }}
                        ></div>
                      ))}
                    </div>

                    {/* Duration */}
                    <div className="text-slate-400 text-sm w-12 text-right">
                      {track.duration}
                    </div>

                    {/* Actions */}
                    <div className="flex items-center gap-2 opacity-0 group-hover:opacity-100 transition-opacity">
                      <button 
                        onClick={() => handleDownload(track)}
                        className="p-2 hover:bg-slate-700 rounded-full transition-colors"
                        title="Download track"
                      >
                        <Download className="w-4 h-4 text-slate-400 hover:text-white" />
                      </button>
                      <button 
                        onClick={() => onToggleLike(track.id)}
                        className="p-2 hover:bg-slate-700 rounded-full transition-colors"
                      >
                        <Heart className={`w-4 h-4 ${track.liked ? 'text-red-400 fill-current' : 'text-slate-400'}`} />
                      </button>
                      <button className="p-2 hover:bg-slate-700 rounded-full transition-colors">
                        <Share2 className="w-4 h-4 text-slate-400" />
                      </button>
                      <button className="p-2 hover:bg-slate-700 rounded-full transition-colors">
                        <MoreHorizontal className="w-4 h-4 text-slate-400" />
                      </button>
                    </div>
                  </div>
                  ))}
                </div>
              ) : (
                <div className="text-center py-16">
                  <Search className="w-16 h-16 text-slate-600 mx-auto mb-4" />
                  <h3 className="text-xl font-semibold text-white mb-2">No music found</h3>
                  <p className="text-slate-400">
                    {searchQuery 
                      ? `No tracks match "${searchQuery}". Try a different search term.`
                      : "Your music library is empty."
                    }
                  </p>
                </div>
              )}
            </div>
          </div>
        );
      
      case 'library':
        return (
          <MusicManager
            music={filteredAndSortedMusic}
            onAddMusic={onAddMusic}
            onDeleteMusic={handleDeleteMusic}
            onToggleLike={onToggleLike}
            onPlayTrack={handlePlayTrack}
            onDownload={handleDownload}
            currentTrack={currentTrack}
            isPlaying={isPlaying}
            canManage={isPremium}
          />
        );
      
      case 'liked':
        return (
          <div className="space-y-6">
            <div>
              <h2 className="text-2xl font-bold text-white">Liked Songs</h2>
              <p className="text-slate-400">
                {likedMusic.length} {likedMusic.length === 1 ? 'song' : 'songs'} you love
              </p>
            </div>
            
            {likedMusic.length > 0 ? (
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
                {likedMusic.map((music) => (
                  <Card key={music.id} className="bg-slate-800/50 border-slate-700 overflow-hidden">
                    <img 
                      src={music.coverUrl} 
                      alt={music.title}
                      className="w-full h-48 object-cover"
                    />
                    <div className="p-4">
                      <h3 className="font-semibold text-white truncate">{music.title}</h3>
                      <p className="text-slate-400 text-sm truncate">{music.artist}</p>
                      <p className="text-slate-500 text-xs truncate">{music.album}</p>
                    </div>
                  </Card>
                ))}
              </div>
            ) : (
              <div className="text-center py-16">
                <Heart className="w-16 h-16 text-slate-600 mx-auto mb-4" />
                <h3 className="text-xl font-semibold text-white mb-2">No liked songs yet</h3>
                <p className="text-slate-400">Start liking songs to see them here!</p>
              </div>
            )}
          </div>
        );
      
      case 'settings':
        return (
          <div className="space-y-8">
            <h2 className="text-2xl font-bold text-white">Settings</h2>
            
            <Card className="bg-slate-800/50 border-slate-700 p-6">
              <h3 className="text-lg font-semibold text-white mb-4">Account Information</h3>
              <div className="space-y-3">
                <div>
                  <label className="text-sm text-slate-400">Name</label>
                  <p className="text-white">{user.name}</p>
                </div>
                <div>
                  <label className="text-sm text-slate-400">Email</label>
                  <p className="text-white">{user.email}</p>
                </div>
                <div>
                  <label className="text-sm text-slate-400">Account Type</label>
                  <div className="flex items-center gap-2">
                    <Badge className={isPremium ? "bg-gradient-to-r from-purple-500 to-blue-500" : "bg-slate-600"}>
                      {isPremium ? (
                        <>
                          <Crown className="w-3 h-3 mr-1" />
                          Premium
                        </>
                      ) : (
                        <>
                          <Users className="w-3 h-3 mr-1" />
                          Demo
                        </>
                      )}
                    </Badge>
                  </div>
                </div>
              </div>
            </Card>
            
            {!isPremium && (
              <Card className="bg-gradient-to-r from-purple-500/10 to-blue-500/10 border-purple-500/30 p-6">
                <h3 className="text-lg font-semibold text-white mb-2">Upgrade to Premium</h3>
                <p className="text-slate-300 mb-4">
                  Unlock unlimited music uploads, advanced features, and more!
                </p>
                <Button 
                  onClick={() => setShowUpgradeModal(true)}
                  className="bg-gradient-to-r from-purple-500 to-blue-500 hover:from-purple-600 hover:to-blue-600 text-white"
                >
                  <Crown className="w-4 h-4 mr-2" />
                  Upgrade Now
                </Button>
              </Card>
            )}
          </div>
        );
      
      default:
        return null;
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-purple-900 to-slate-900 flex">
      {/* Sidebar */}
      <div className="w-64 bg-black/20 backdrop-blur-lg border-r border-slate-700 flex flex-col">
        {/* Logo */}
        <div className="p-6 border-b border-slate-700">
          <div className="flex items-center gap-3">
            <div className="bg-gradient-to-r from-purple-500 to-blue-500 rounded-full p-2">
              <Music className="w-6 h-6 text-white" />
            </div>
            <h1 className="text-xl font-bold text-white">Mussoul</h1>
          </div>
        </div>
        
        {/* Navigation */}
        <nav className="flex-1 p-4">
          <ul className="space-y-2">
            {sidebarItems.map((item) => {
              const Icon = item.icon;
              const isActive = currentView === item.id;
              
              return (
                <li key={item.id}>
                  <button
                    onClick={() => setCurrentView(item.id as any)}
                    className={`w-full flex items-center gap-3 px-3 py-2 rounded-lg transition-colors ${
                      isActive 
                        ? 'bg-purple-500/20 text-purple-400' 
                        : 'text-slate-300 hover:bg-slate-800/50 hover:text-white'
                    }`}
                  >
                    <Icon className="w-5 h-5" />
                    {item.label}
                  </button>
                </li>
              );
            })}
          </ul>
        </nav>
        
        {/* User Profile */}
        <div className="p-4 border-t border-slate-700">
          <div className="flex items-center gap-3 mb-3">
            <Avatar>
              <AvatarFallback className="bg-purple-500 text-white">
                {user.name.charAt(0).toUpperCase()}
              </AvatarFallback>
            </Avatar>
            <div className="flex-1 min-w-0">
              <p className="font-semibold text-white truncate">{user.name}</p>
              <Badge className={`text-xs ${isPremium ? "bg-purple-500" : "bg-slate-600"}`}>
                {isPremium ? "Premium" : "Demo"}
              </Badge>
            </div>
          </div>
          <Button 
            onClick={onLogout}
            variant="ghost" 
            className="w-full justify-start text-slate-400 hover:text-white hover:bg-slate-800/50"
          >
            <LogOut className="w-4 h-4 mr-2" />
            Sign Out
          </Button>
        </div>
      </div>
      
      {/* Main Content */}
      <div className="flex-1 flex flex-col">
        {/* Header */}
        <header className="bg-black/20 backdrop-blur-lg border-b border-slate-700 p-6">
          <div className="flex items-center gap-4">
            <div className="flex-1 max-w-md">
              <div className="relative">
                <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 w-4 h-4 text-slate-400" />
                <Input
                  placeholder="Search your music..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="pl-10 bg-slate-800/50 border-slate-600 text-white placeholder-slate-400"
                />
              </div>
            </div>
            <div className="flex items-center gap-2">
              <ArrowUpDown className="w-4 h-4 text-slate-400" />
              <select
                value={sortBy}
                onChange={(e) => setSortBy(e.target.value as typeof sortBy)}
                className="bg-slate-800/50 border border-slate-600 rounded-lg px-3 py-2 text-white text-sm"
              >
                <option value="recent">Sort by Recent</option>
                <option value="title">Sort by Title</option>
                <option value="artist">Sort by Artist</option>
                <option value="genre">Sort by Genre</option>
                <option value="duration">Sort by Duration</option>
              </select>
            </div>
          </div>
        </header>
        
        {/* Content */}
        <main className={`flex-1 p-6 overflow-auto ${currentTrack ? 'pb-24' : ''}`}>
          {renderContent()}
        </main>
      </div>

      {/* Audio Player */}
      <AudioPlayer
        currentTrack={currentTrack}
        playlist={musicLibrary}
        isPlaying={isPlaying}
        onPlay={handlePlay}
        onPause={handlePause}
        onNext={handleNext}
        onPrevious={handlePrevious}
        onClose={handleClosePlayer}
        onToggleLike={onToggleLike}
      />

      {/* Upgrade Modal */}
      <UpgradeModal
        isOpen={showUpgradeModal}
        onClose={() => setShowUpgradeModal(false)}
        onUpgrade={onUpgrade}
        currentUser={user}
      />
    </div>
  );
}