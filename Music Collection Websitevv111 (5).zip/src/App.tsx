import { useState, useEffect } from 'react';
import { WelcomePage } from './components/WelcomePage';
import { AuthModal } from './components/AuthModal';
import { Dashboard } from './components/Dashboard';

interface User {
  name: string;
  email: string;
  accountType: 'demo' | 'premium';
}

interface Music {
  id: string;
  title: string;
  artist: string;
  album: string;
  duration: string;
  genre: string;
  coverUrl: string;
  audioUrl?: string;
  liked?: boolean;
}

export default function App() {
  const [user, setUser] = useState<User | null>(null);
  const [showAuthModal, setShowAuthModal] = useState(false);
  const [musicLibrary, setMusicLibrary] = useState<Music[]>([]);

  // Load data from localStorage on app start
  useEffect(() => {
    const savedUser = localStorage.getItem('mussoul-user');
    const savedMusic = localStorage.getItem('mussoul-music');
    
    if (savedUser) {
      try {
        setUser(JSON.parse(savedUser));
      } catch (error) {
        console.error('Failed to load user data:', error);
      }
    }
    
    if (savedMusic) {
      try {
        setMusicLibrary(JSON.parse(savedMusic));
      } catch (error) {
        console.error('Failed to load music data:', error);
        // Load default music if saved data is corrupted
        setMusicLibrary(getDefaultMusic());
      }
    } else {
      // Load default music for new users
      setMusicLibrary(getDefaultMusic());
    }
  }, []);

  // Save music to localStorage whenever it changes
  useEffect(() => {
    if (musicLibrary.length > 0) {
      localStorage.setItem('mussoul-music', JSON.stringify(musicLibrary));
    }
  }, [musicLibrary]);

  // Save user to localStorage whenever it changes
  useEffect(() => {
    if (user) {
      localStorage.setItem('mussoul-user', JSON.stringify(user));
    } else {
      localStorage.removeItem('mussoul-user');
    }
  }, [user]);

  // Default music data
  const getDefaultMusic = (): Music[] => [
    {
      id: '1',
      title: 'Bohemian Rhapsody',
      artist: 'Queen',
      album: 'A Night at the Opera',
      duration: '5:55',
      genre: 'Rock',
      coverUrl: 'https://images.unsplash.com/photo-1493225457124-a3eb161ffa5f?w=400&h=400&fit=crop&crop=center',
      liked: true,
      audioUrl: 'https://www.soundjay.com/misc/sounds/bell-ringing-05.wav'
    },
    {
      id: '2',
      title: 'Hotel California',
      artist: 'Eagles',
      album: 'Hotel California',
      duration: '6:30',
      genre: 'Rock',
      coverUrl: 'https://images.unsplash.com/photo-1629426958038-a4cb6e3830a0?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxtdXNpYyUyMHZpbnlsJTIwcmVjb3JkfGVufDF8fHx8MTc1ODA5NTU5Mnww&ixlib=rb-4.1.0&q=80&w=1080',
      audioUrl: 'https://www.soundjay.com/misc/sounds/spring-birds-04.wav'
    },
    {
      id: '3',
      title: 'Billie Jean',
      artist: 'Michael Jackson',
      album: 'Thriller',
      duration: '4:54',
      genre: 'Pop',
      coverUrl: 'https://images.unsplash.com/photo-1571330735066-03aaa9429d89?w=400&h=400&fit=crop&crop=center',
      liked: true,
      audioUrl: 'https://www.soundjay.com/misc/sounds/soft-wind-chimes-01.wav'
    },
    {
      id: '4',
      title: 'Electronic Dreams',
      artist: 'Synthwave Artist',
      album: 'Neon Nights',
      duration: '3:42',
      genre: 'Electronic',
      coverUrl: 'https://images.unsplash.com/photo-1643240150280-33a05caf8415?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxlbGVjdHJvbmljJTIwbXVzaWMlMjBoZWFkcGhvbmVzfGVufDF8fHx8MTc1ODA5NTU5N3ww&ixlib=rb-4.1.0&q=80&w=1080',
      liked: false
    },
    {
      id: '5',
      title: 'Smooth Jazz Evening',
      artist: 'Jazz Ensemble',
      album: 'Late Night Sessions',
      duration: '4:18',
      genre: 'Jazz',
      coverUrl: 'https://images.unsplash.com/photo-1687589891979-d17de92e5802?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxqYXp6JTIwcGlhbm8lMjBtdXNpY3xlbnwxfHx8fDE3NTgwOTU2MDJ8MA&ixlib=rb-4.1.0&q=80&w=1080',
      liked: true
    }
  ];

  // Music management functions
  const addMusic = (newMusic: Omit<Music, 'id'>) => {
    const music: Music = {
      ...newMusic,
      id: Date.now().toString()
    };
    setMusicLibrary(prev => [...prev, music]);
  };

  const deleteMusic = (id: string) => {
    setMusicLibrary(prev => prev.filter(music => music.id !== id));
  };

  const toggleLike = (id: string) => {
    setMusicLibrary(prev => prev.map(music => 
      music.id === id ? { ...music, liked: !music.liked } : music
    ));
  };

  const handleAuth = (authenticatedUser: User) => {
    setUser(authenticatedUser);
    setShowAuthModal(false);
  };

  const handleLogout = () => {
    setUser(null);
  };

  const handleUpgrade = () => {
    if (user) {
      setUser({
        ...user,
        accountType: 'premium'
      });
    }
  };

  if (user) {
    return (
      <Dashboard 
        user={user} 
        onLogout={handleLogout} 
        onUpgrade={handleUpgrade}
        musicLibrary={musicLibrary}
        onAddMusic={addMusic}
        onDeleteMusic={deleteMusic}
        onToggleLike={toggleLike}
      />
    );
  }

  return (
    <>
      <WelcomePage onShowAuth={() => setShowAuthModal(true)} />
      <AuthModal
        isOpen={showAuthModal}
        onClose={() => setShowAuthModal(false)}
        onAuth={handleAuth}
      />
    </>
  );
}