
  # Music Collection Websitevv111

  This is a code bundle for Music Collection Websitevv111. The original project is available at https://www.figma.com/design/dJHSPca4C8qKgcDGbZW0za/Music-Collection-Websitevv111.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  